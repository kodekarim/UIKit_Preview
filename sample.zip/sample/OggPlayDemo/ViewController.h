//
//  ViewController.h
//  OggPlayDemo
//
//  Created by Danila Shikulin on 16/4/12.
//  Copyright (c) 2012 COS. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PASoundSource.h"

@interface ViewController : UIViewController

@property (nonatomic, strong) PASoundSource *audioSource;

@end
