//
//  vorbis.h
//  vorbis
//
//  Created by Danila Shikulin on 16/4/12.
//  Copyright (c) 2012 COS. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface vorbis : NSObject

@end
