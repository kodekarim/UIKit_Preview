//
//  vorbis.m
//  vorbis
//
//  Created by Danila Shikulin on 16/4/12.
//  Copyright (c) 2012 COS. All rights reserved.
//

#import "vorbis.h"

@implementation vorbis

@end
